## Same-seed gameplay parity, separating VM metric bytes from game behavior.
import std/[os,json]
import ../../replays
let args=commandLineParams()
doAssert args.len==2
let a=loadReplay(args[0])
let b=loadReplay(args[1])
echo $(%*{"all_actions_equal":a.actions==b.actions,
  "all_state_hashes_equal":a.hashes==b.hashes,
  "setup_equal":a.header.setup==b.header.setup,
  "config_equal":a.config==b.config,
  "metrics_equal":a.metrics==b.metrics,
  "ticks_a":a.hashes.len,"ticks_b":b.hashes.len,
  "same_seed":a.config.seed==b.config.seed})
