## Reconstruct the initial VM order from the replay's exact game configuration.
import std/json
import ../../game
if not game.run.replayMode: raise newException(ValueError, "--replay required")
echo $(%*{"initial_vm_slot": game.run.world.heroTurnStart,
  "heroes": game.run.world.heroes.len,
  "ticks": game.run.world.tick,
  "replay_ticks": game.run.replayData.hashes.len})
