## Independent physical support check at recorded tower-command boundaries.
## Samples the pre-tick state; no newly spawned same-tick creep is credited.
import std/[json, tables]
import ../../[game, sim, replays]

if not run.replayMode: raise newException(ValueError, "--replay required")
var towerCommands, unsupported, stickyHero, fortCommands: array[10, int]
var firstFort: array[10, int]
var towerHits, unsupportedHits, openingHits, unsupportedOpenings: array[10,int]
var lastHitTower, lastTowerHitTick: array[10,int]
var laneCommands: array[10, array[3, int]]
var examples = newJArray()
for i in 0..<10: firstFort[i] = -1
while run.world.tick < run.replayData.hashes.len and not run.world.gameOver:
  let nextTick = run.world.tick + 1
  var previousHits: array[10,int]
  var support = initTable[int32,bool]()
  proc supportedAt(id:int32):bool =
    if id in support:return support[id]
    let bi=buildingIndex(run.world,id)
    if bi<0:return false
    let tower=run.world.buildings[bi]
    if tower.kind!=TowerBuilding:return false
    let radius=int64(TowerAttackRanges[tower.tier])
    for creep in run.world.footmen:
      if creep.team==tower.team or creep.hp<=0 or creep.state==Dying:continue
      let dx=int64(creep.position.x)-tower.position.x
      let dz=int64(creep.position.z)-tower.position.z
      if dx*dx+dz*dz<=radius*radius:result=true
    support[id]=result
  for slot,hero in run.world.heroes:
    previousHits[slot]=hero.attacksLanded.int
    discard supportedAt(hero.attackObjectId)
  var index = run.replayPlayer.actionIndex
  while index < run.replayData.actions.len:
    let action = run.replayData.actions[index]
    if action.tick.int > nextTick: break
    if action.tick.int == nextTick and action.kind == ActionAttackTarget:
      let slot = heroIndex(run.world, action.heroId)
      let hero = run.world.heroes[slot]
      let bi = buildingIndex(run.world, action.first)
      if bi >= 0:
        let tower = run.world.buildings[bi]
        if tower.kind == TowerBuilding and tower.hp > 0:
          inc towerCommands[slot]
          inc laneCommands[slot][tower.lane]
          let supported = supportedAt(tower.id)
          if not supported:
            inc unsupported[slot]
            if examples.len < 20: examples.add(%*{"slot":slot,"tick":nextTick,"tower":tower.id})
          if heroIndex(run.world,tower.targetId) >= 0: inc stickyHero[slot]
      else:
        for fort in run.world.forts:
          if action.first == fort.id:
            inc fortCommands[slot]
            if firstFort[slot] < 0: firstFort[slot] = nextTick
    inc index
  advanceGame()
  for slot,hero in run.world.heroes:
    let bi=buildingIndex(run.world,hero.targetBuildingId)
    if hero.attacksLanded.int>previousHits[slot] and bi>=0 and run.world.buildings[bi].kind==TowerBuilding:
      inc towerHits[slot]
      let id=hero.targetBuildingId
      let supported=support.getOrDefault(id,false)
      if not supported:inc unsupportedHits[slot]
      if lastHitTower[slot]!=id.int or nextTick-lastTowerHitTick[slot]>240:
        inc openingHits[slot]
        if not supported:inc unsupportedOpenings[slot]
      lastHitTower[slot]=id.int
      lastTowerHitTick[slot]=nextTick
if run.hashCheck.mismatches != 0 or run.replayPlayer.actionIndex != run.replayData.actions.len:
  raise newException(ValueError,"Incomplete or divergent coaching audit")
echo $(%*{"ticks":run.world.tick,"hash_mismatches":run.hashCheck.mismatches,
  "actions_consumed":run.replayPlayer.actionIndex,"tower_commands":towerCommands,
  "unsupported_tower_commands":unsupported,"tower_commands_while_targeting_hero":stickyHero,
  "lane_tower_commands":laneCommands,"fort_commands":fortCommands,"first_fort_command":firstFort,
  "tower_basic_hits":towerHits,"unsupported_basic_hits":unsupportedHits,
  "tower_opening_hits":openingHits,"unsupported_opening_hits":unsupportedOpenings,
  "unsupported_examples":examples,"sampling":"Exact pre-tick physical positions; same-tick newly spawned creeps are not credited."})
