## Reconstruct owned VM state by replaying rivals and rerunning our exact source.
## Every generated owned command and every resulting state hash must match tape.
import std/[json, os, strutils]
import ../../game
include ../../bots

proc applyReplayAction(world: World, action: ReplayAction): bool {.discardable.} =
  ## Applies one recorded bot command without requiring its private VM.
  case action.kind
  of ActionWalkTo:
    applyWalkTo(world, action.heroId, action.first, action.second)
  of ActionAttackMove:
    applyAttackMove(
      world, action.heroId, action.first, action.second
    )
  of ActionAttackTarget:
    applyAttackTarget(world, action.heroId, action.first)
  of ActionBuyItem:
    applyBuyItem(world, action.heroId, action.first)
  of ActionUseItem:
    applyUseItem(world, action.heroId, action.first)
  of ActionCastTarget .. ActionCastPoint - 1:
    applyCastTarget(world, action.heroId,
      int32(action.kind - ActionCastTarget), action.first)
  of ActionCastPoint .. ActionManualSpells - 1:
    applyCastPoint(world, action.heroId,
      int32(action.kind - ActionCastPoint), action.first, action.second)
  of ActionManualSpells:
    let index = world.heroIndex(action.heroId)
    if index >= 0:
      world.heroes[index].manualSpells = action.first != 0
    false
  else:
    raise newException(ReplayError, "replay action kind is invalid")

if not game.run.replayMode:raise newException(ValueError,"--replay required")
let tape=game.run.replayData
let slotText=getEnv("PROBE_SLOTS")
if slotText.len==0:raise newException(ValueError,"PROBE_SLOTS required")
var controlled:array[10,bool]
var probeSlots:seq[int]
for item in slotText.split(','):
  let slot=parseInt(item)
  if slot<0 or slot>=10 or controlled[slot]:raise newException(ValueError,"Invalid/duplicate owned slot")
  controlled[slot]=true
  probeSlots.add(slot)
loadBots(game.run, [BotGroup(path:getEnv("PROBE_POLICY"),count:10)])
game.run.historyPlayback=false
startReplayRecording(uint32(tape.hashes.len))
var index=0
var checked=0
var decisions=0
var assistCounts:array[10,int]
var assistLast:array[10,bool]
while game.run.world.tick<tape.hashes.len and not game.run.world.gameOver:
  tickWorld(game.run, proc() =
    var perSlot:array[10,seq[ReplayAction]]
    while index<tape.actions.len and tape.actions[index].tick==uint32(game.run.world.tick):
      let a=tape.actions[index]
      if a.kind==ActionManualSpells:discard applyReplayAction(game.run.world,a)
      else:perSlot[heroIndex(game.run.world,a.heroId)].add(a)
      inc index
    for offset in 0..<10:
      let slot=(game.run.world.heroTurnStart+offset) mod 10
      if not controlled[slot]:
        for a in perSlot[slot]:discard applyReplayAction(game.run.world,a)
      else:
        let first=game.run.recorder.data.actions.len
        let vm=game.run.heroVms[slot]
        let before=vm.decisions
        runHeroScript(game.run,slot)
        if vm.failed:raise newException(ValueError,vm.lastError)
        let actual=game.run.recorder.data.actions[first..<game.run.recorder.data.actions.len]
        if actual != perSlot[slot]:
          echo $(%*{"type":"command_mismatch","tick":game.run.world.tick,"slot":slot,"expected":perSlot[slot],"actual":actual})
          quit(2)
        checked+=actual.len
        if vm.decisions>before:
          inc decisions
          let assisting = vm.runtime.getGlobal("defActive") != 0 and
            vm.runtime.getGlobal("aaCommitted") != 0 and
            vm.runtime.getGlobal("aaDistance") > 100 and
            vm.runtime.getGlobal("bestId") != 0 and
            vm.runtime.getGlobal("bestId") == vm.runtime.getGlobal("defFront")
          if assisting:
            inc assistCounts[slot]
          if assisting and not assistLast[slot]:
            let actor = game.run.world.heroes[slot]
            var allies = newJArray()
            for oi in 0 ..< game.run.world.worldObjectCount(actor.id):
              var o: WorldObject
              if game.run.world.worldObjectAt(actor.id, oi, o) and o.kind == 2 and o.team == actor.team and o.id != actor.id:
                allies.add(%*{"id":o.id,"class_id":o.class,"hp":o.hp,
                  "x":mapCoordinate(o.position.x),"y":mapCoordinate(o.position.z),
                  "targets_front":o.targetId == vm.runtime.getGlobal("defFront")})
            echo $(%*{"type":"expanded_assist_start","tick":game.run.world.tick,"slot":slot,
              "class_id":actor.class.ord,"class_name": $actor.class,"hp":actor.hp,"max_hp":actor.maxHp,
              "x":mapCoordinate(actor.position.x),"y":mapCoordinate(actor.position.z),
              "target":vm.runtime.getGlobal("bestId"),"distance_squared":vm.runtime.getGlobal("aaDistance"),
              "front_x":vm.runtime.getGlobal("defFrontX"),"front_y":vm.runtime.getGlobal("defFrontY"),
              "enemy_cluster":vm.runtime.getGlobal("defCount"),"anchor":vm.runtime.getGlobal("defAnchor"),
              "allies":allies})
          assistLast[slot]=assisting
          if game.run.world.tick mod 120==0:
            var memory=newJObject()
            for name in ["bestId","defActive","defUntil","defHoldTicks","defFront","defCount","defAnchor","defPointX","defPointY","defThreatX","defThreatY","defNavX","defNavY","defMoveAccepted","perimeterAnchor","perimeterX","perimeterY","perimeterLastCombat","perimeterEnabled","backdoorActive","coreId","aaReady","aaCommitted","aaDistance"]:
              try:memory[name]= %vm.runtime.getGlobal(name)
              except BasicError:discard
            echo $(%*{"type":"decision","tick":game.run.world.tick,"slot":slot,"class_id":game.run.world.heroes[slot].class.ord,"class_name": $game.run.world.heroes[slot].class,"memory":memory,"actions":actual})
    game.run.world.heroTurnStart=(game.run.world.heroTurnStart+1) mod 10
  )
  if game.run.stateHash()!=tape.hashes[game.run.world.tick-1]:
    echo $(%*{"type":"hash_mismatch","tick":game.run.world.tick})
    quit(3)
echo $(%*{"type":"summary","controlled_slots":probeSlots,"ticks":game.run.world.tick,"expanded_assist_decisions":assistCounts,"owned_commands_matched":checked,"owned_decisions":decisions,"all_state_hashes_equal":true,"all_actions_consumed":index==tape.actions.len})
