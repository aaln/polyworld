## Compare gameplay independently of the recorded VM work/instruction metrics.
import std/[os, json]
import ../../replays
let args = commandLineParams()
doAssert args.len == 2
let a = loadReplay(args[0])
let b = loadReplay(args[1])
doAssert a.config == b.config, "Replay configuration differs"
doAssert a.header.setup == b.header.setup, "Initial setup differs"
doAssert a.actions == b.actions, "Recorded actions differ"
doAssert a.hashes == b.hashes, "Per-tick game state differs"
echo $(%*{"actions": a.actions.len, "ticks": a.hashes.len,
  "all_actions_equal": true, "all_states_equal": true,
  "metrics_equal": a.metrics == b.metrics})
