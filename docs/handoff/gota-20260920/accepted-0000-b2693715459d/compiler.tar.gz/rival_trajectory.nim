## Compare all recorded actions independently of seed-dependent animation hashes.
import std/[os,json]
import ../../replays
let args=commandLineParams()
doAssert args.len==2
let a=loadReplay(args[0])
let b=loadReplay(args[1])
var aa,bb: array[10,seq[ReplayAction]]
for action in a.actions:
  doAssert action.heroId in 100..109
  aa[action.heroId-100].add(action)
for action in b.actions:
  doAssert action.heroId in 100..109
  bb[action.heroId-100].add(action)
echo $(%*{"all_actions_equal":a.actions==b.actions,"all_per_hero_tick_commands_equal":aa==bb,"ticks_a":a.hashes.len,"ticks_b":b.hashes.len,
 "actions_a":a.actions.len,"actions_b":b.actions.len,"same_seed":a.config.seed==b.config.seed,
 "meaning":"Full command-tape equality only; simulation RNG/state hashes and VM metrics may differ."})
