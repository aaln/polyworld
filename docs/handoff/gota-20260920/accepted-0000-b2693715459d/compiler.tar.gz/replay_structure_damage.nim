## Reconstruct structure HP losses and creep swings from a verified replay.
## Does not modify simulation or policy decisions.
import std/[json, tables]
import ../../[game, sim, replays]

if not run.replayMode: raise newException(ValueError, "--replay required")
proc point(p: WorldPoint): JsonNode =
  %*[p.x.float64 / 60000 + 58, p.z.float64 / 60000 + 58]
proc health(): Table[int32, int32] =
  for b in run.world.buildings: result[b.id] = b.hp
  for f in run.world.forts: result[f.id] = f.hp

while run.world.tick < run.replayData.hashes.len and not run.world.gameOver:
  let before = health()
  var landed = initTable[int32, bool]()
  for f in run.world.footmen: landed[f.id] = f.damageLanded
  advanceGame()
  var damage = newJArray()
  for id, hp in health():
    if id in before and hp < before[id]:
      damage.add(%*{"id":id,"before":before[id],"after":hp})
  if damage.len > 0:
    var hits, heroes = newJArray()
    for f in run.world.footmen:
      if f.damageLanded and not landed.getOrDefault(f.id):
        hits.add(%*{"id":f.id,"team":f.team.ord,"position":point(f.position),
          "target_building":f.targetBuildingId,"target_hero":f.targetHeroId,
          "target_creep":f.targetId,"attacking_fort":f.attackingFort})
    for h in run.world.heroes:
      heroes.add(%*{"id":h.id,"team":h.team.ord,"position":point(h.position),
        "hp":h.hp,"target":h.attackObjectId})
    echo $(%*{"type":"damage","tick":run.world.tick,"structures":damage,
      "creep_swings_landed":hits,"heroes":heroes})
if run.hashCheck.mismatches != 0 or run.replayPlayer.actionIndex != run.replayData.actions.len or run.world.tick != run.replayData.hashes.len:
  raise newException(ValueError,"Incomplete or divergent replay")
echo $(%*{"type":"summary","ticks":run.world.tick,"hash_mismatches":run.hashCheck.mismatches,
  "actions_consumed":run.replayPlayer.actionIndex,"winner":run.world.winner.ord})
