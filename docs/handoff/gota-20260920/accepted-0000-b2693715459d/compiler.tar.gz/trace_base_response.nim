## Complete replay validation with per-tick target/visibility trace after180s.
import std/json
import ../../[game, sim, replays, content]
if not run.replayMode:raise newException(ValueError,"--replay required")
proc point(p:WorldPoint):JsonNode=
  %*[p.x.float64/60000+58,p.z.float64/60000+58]
echo $(%*{"type":"header","version":"2026.9.16.5","source":"f2ab9598d8f8001b6beae3e66404e341770c803f",
          "note":"Post-tick states; not the earlier VM decision snapshot."})
while run.world.tick < run.replayData.hashes.len and not run.world.gameOver:
  advanceGame()
  if run.world.tick >= 180*24:
    var heroes=newJArray()
    for slot,h in run.world.heroes:
      var visible=newJArray()
      if slot in [6,7]:
        for i in 0..<run.world.worldObjectCount(h.id):
          var o:WorldObject
          if run.world.worldObjectAt(h.id,i,o) and o.kind==2 and o.hp>0:
            visible.add(%o.id)
      heroes.add(%*{"slot":slot,"id":h.id,"team":h.team.ord,"position":point(h.position),
                    "hp":h.hp,"target":h.attackObjectId,"visible_heroes":visible})
    var cores=newJArray()
    for b in run.world.buildings:
      if b.id in [28,29,30,31]:cores.add(%*{"id":b.id,"hp":b.hp})
    for f in run.world.forts:cores.add(%*{"id":f.id,"hp":f.hp})
    echo $(%*{"type":"tick","tick":run.world.tick,"heroes":heroes,"cores":cores})
if run.hashCheck.mismatches != 0 or run.replayPlayer.actionIndex != run.replayData.actions.len or run.world.tick != run.replayData.hashes.len:
  raise newException(ValueError,"Incomplete or divergent replay")
echo $(%*{"type":"summary","ticks":run.world.tick,"hash_mismatches":run.hashCheck.mismatches,
          "actions_consumed":run.replayPlayer.actionIndex,"winner":run.world.winner.ord})
