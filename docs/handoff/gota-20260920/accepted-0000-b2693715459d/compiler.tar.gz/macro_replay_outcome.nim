## Ground-truth macro replay frames; observations are explicitly post-tick.
import std/[json, strutils]
import ../../[game, sim, replays, content, terrains, maps]

if not run.replayMode: raise newException(ValueError, "--replay required")
proc point(p: WorldPoint): JsonNode =
  %*[p.x.float64 / 60000 + 58, p.z.float64 / 60000 + 58]
proc buildings(): JsonNode =
  result = newJArray()
  for b in run.world.buildings:
    result.add(%*{"id":b.id,"kind": $b.kind,"team":b.team.ord,"lane":b.lane,
      "tier":b.tier.ord,"position":point(b.position),"hp":b.hp,"max_hp":b.maxHp})
  for f in run.world.forts:
    result.add(%*{"id":f.id,"kind":"Fort","team":f.team.ord,"lane": -1,
      "position":point(f.center),"hp":f.hp})
var terrain = newJArray()
for y in 0 ..< mapTiles():
  var row = ""
  for x in 0 ..< mapTiles():
    row.add(if terrainValue(x.int32,y.int32,0,TerrainWalkableField) != 0: '.' else: '#')
  terrain.add(%row)
echo $(%*{"type":"header","version":"2026.9.16.5","source":"f2ab9598d8f8001b6beae3e66404e341770c803f",
  "terrain":terrain,"buildings":buildings(),"note":"Recorded ground truth; visible lists are post-tick, not the earlier policy decision snapshot."})
while run.world.tick < run.replayData.hashes.len and not run.world.gameOver:
  let start = run.replayPlayer.actionIndex
  advanceGame()
  for i in start ..< run.replayPlayer.actionIndex:
    let a = run.replayData.actions[i]
    if a.kind in [ActionWalkTo, ActionAttackTarget, ActionBuyItem]:
      echo $(%*{"type":"action","tick":run.world.tick,"slot":heroIndex(run.world,a.heroId),
        "kind":a.kind,"first":a.first,"second":a.second})
  if run.world.tick mod 120 == 0 or run.world.gameOver:
    var heroes = newJArray()
    for slot,h in run.world.heroes:
      var visible = newJArray()
      for i in 0 ..< run.world.worldObjectCount(h.id):
        var o: WorldObject
        if run.world.worldObjectAt(h.id,i,o):
          visible.add(%*{"id":o.id,"kind":o.kind,"team":o.team.ord,"hp":o.hp,"position":point(o.position)})
      heroes.add(%*{"slot":slot,"id":h.id,"class": $h.class,"team":h.team.ord,"position":point(h.position),
        "hp":h.hp,"max_hp":h.maxHp,"level":h.level,"xp":h.totalXp,"gold":h.gold,
        "inventory":h.inventory,"target":h.attackObjectId,"hits":h.attacksLanded,"visible_post_tick":visible})
    echo $(%*{"type":"frame","tick":run.world.tick,"heroes":heroes,"buildings":buildings()})
if run.hashCheck.mismatches != 0 or run.replayPlayer.actionIndex != run.replayData.actions.len or run.world.tick != run.replayData.hashes.len:
  raise newException(ValueError,"Incomplete or divergent replay")
echo $(%*{"type":"summary","ticks":run.world.tick,"hash_mismatches":run.hashCheck.mismatches,
  "actions_consumed":run.replayPlayer.actionIndex,"timeout":not run.world.gameOver,"winner":(if run.world.gameOver:run.world.winner.ord else: -1)})
