## Canonical complete per-hero/tick command stream for already audited replays.
## Not a simulation auditor. Pair with a complete pinned native audit.
import std/[os,json]
import ../../replays
let args=commandLineParams()
doAssert args.len==1
let tape=loadReplay(args[0])
var data=newStringOfCap(tape.actions.len*16)
proc u32(value:uint32)=
  for shift in [0,8,16,24]:data.add(char((value shr shift) and 255))
var index=0
var groups=0
var previousTick=0'u32
while index<tape.actions.len:
  let tick=tape.actions[index].tick
  doAssert tick>=previousTick
  previousTick=tick
  var perSlot:array[10,seq[ReplayAction]]
  while index<tape.actions.len and tape.actions[index].tick==tick:
    let a=tape.actions[index]
    doAssert a.heroId in 100..109
    perSlot[a.heroId-100].add(a)
    inc index
  for slot in 0..<10:
    if perSlot[slot].len>0:
      inc groups
      u32(tick);u32(uint32(slot));u32(uint32(perSlot[slot].len))
      for a in perSlot[slot]:
        u32(uint32(a.kind));u32(cast[uint32](a.first));u32(cast[uint32](a.second))
stdout.write(data)
stderr.writeLine($(%*{"schema":"gota-full-command-stream/1","ticks":tape.hashes.len,
  "actions_consumed":tape.actions.len,"groups":groups,"bytes":data.len,
  "encoding":"little-endian u32 tick,slot,command_count; then u32 kind,i32 first,i32 second for every command. Groups sorted by tick then slot; original within-group order retained."}))
