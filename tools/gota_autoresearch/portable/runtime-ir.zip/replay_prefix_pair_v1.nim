## Compare already audited replay setup and complete canonical state-hash prefixes.
## This does not replace simulation auditing or measure decision quality.
import std/[os, json]
import ../../replays
let args = commandLineParams()
doAssert args.len == 2
let left = loadReplay(args[0])
let right = loadReplay(args[1])
var samePrefix = 0
let commonTicks = min(left.hashes.len, right.hashes.len)
for index in 0..<commonTicks:
  if left.hashes[index] != right.hashes[index]: break
  inc samePrefix
echo $(%*{"schema":"gota-audited-replay-prefix/1",
  "same_setup":left.header.setup == right.header.setup,
  "same_config":left.config == right.config,
  "left_ticks":left.hashes.len,"right_ticks":right.hashes.len,
  "common_ticks":commonTicks,"equal_initial_state_hash_ticks":samePrefix,
  "first_hash_difference_tick":(if samePrefix < commonTicks: samePrefix+1 else: 0),
  "interpretation":"Read only comparison of canonical hashes stored in already audited complete tapes. Different seeds can alter header equality; exact state hash equality is reported separately. No alternative rollout or decision-quality verdict."})
