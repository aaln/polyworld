"""Unambiguous cache-only critical recall reference; reuse canonical route binding."""
from binding import CONTRACTS
from autoresearch_target_work_v1 import target_work
from autoresearch_fused_wave_work_v2 import observe_v2
from games.gods_of_the_arena.instruments.richard_counter import contracts

CONTRACTS['lineup_critical_runtime_reference_v1']=observe_v2(target_work(CONTRACTS['lineup_critical_recall']))
# The matching cached fallback already has one canonical registration:
# lineup_fused_wave_route_v1. Do not import historical duplicate aliases.
