## Versioned public pre-decision cooldown and dense-memory arbitration observations.
## Observational full-state cadence diagnostic; post-tick ground truth is never a policy belief.
## Reconstruct owned VM state by replaying rivals and rerunning our exact source.
## Every generated owned command and every resulting state hash must match tape.
import std/[json, os, strutils]
import ../../game
include ../../bots

proc applyReplayAction(world: World, action: ReplayAction): bool {.discardable.} =
  ## Applies one recorded bot command without requiring its private VM.
  case action.kind
  of ActionWalkTo:
    applyWalkTo(world, action.heroId, action.first, action.second)
  of ActionAttackMove:
    applyAttackMove(
      world, action.heroId, action.first, action.second
    )
  of ActionAttackTarget:
    applyAttackTarget(world, action.heroId, action.first)
  of ActionBuyItem:
    applyBuyItem(world, action.heroId, action.first)
  of ActionUseItem:
    applyUseItem(world, action.heroId, action.first)
  of ActionCastTarget .. ActionCastPoint - 1:
    applyCastTarget(world, action.heroId,
      int32(action.kind - ActionCastTarget), action.first)
  of ActionCastPoint .. ActionManualSpells - 1:
    applyCastPoint(world, action.heroId,
      int32(action.kind - ActionCastPoint), action.first, action.second)
  of ActionManualSpells:
    let index = world.heroIndex(action.heroId)
    if index >= 0:
      world.heroes[index].manualSpells = action.first != 0
    false
  else:
    raise newException(ReplayError, "replay action kind is invalid")

if not game.run.replayMode:raise newException(ValueError,"--replay required")
let tape=game.run.replayData
## Use 1 to inspect brief visibility/recall transitions; default keeps old traces.
let sampleEvery=parseInt(getEnv("PROBE_SAMPLE_EVERY", "120"))
if sampleEvery<1:raise newException(ValueError,"PROBE_SAMPLE_EVERY must be positive")
let slotText=getEnv("PROBE_SLOTS")
if slotText.len==0:raise newException(ValueError,"PROBE_SLOTS required")
var controlled:array[10,bool]
var probeSlots:seq[int]
for item in slotText.split(','):
  let slot=parseInt(item)
  if slot<0 or slot>=10 or controlled[slot]:raise newException(ValueError,"Invalid/duplicate owned slot")
  controlled[slot]=true
  probeSlots.add(slot)
loadBots(game.run, [BotGroup(path:getEnv("PROBE_POLICY"),count:10)])
game.run.historyPlayback=false
startReplayRecording(uint32(tape.hashes.len))
var index=0
var checked=0
var decisions=0
while game.run.world.tick<tape.hashes.len and not game.run.world.gameOver:
  tickWorld(game.run, proc() =
    var perSlot:array[10,seq[ReplayAction]]
    while index<tape.actions.len and tape.actions[index].tick==uint32(game.run.world.tick):
      let a=tape.actions[index]
      if a.kind==ActionManualSpells:discard applyReplayAction(game.run.world,a)
      else:perSlot[heroIndex(game.run.world,a.heroId)].add(a)
      inc index
    for offset in 0..<10:
      let slot=(game.run.world.heroTurnStart+offset) mod 10
      if not controlled[slot]:
        for a in perSlot[slot]:discard applyReplayAction(game.run.world,a)
      else:
        let first=game.run.recorder.data.actions.len
        let vm=game.run.heroVms[slot]
        let before=vm.decisions
        let beforeHero = game.run.world.heroes[slot]
        let beforeSelf = %*{"class":ord(beforeHero.class),"level":beforeHero.level,"hp":beforeHero.hp,"maxHp":beforeHero.maxHp,"mana":beforeHero.mana,"x":mapCoordinate(beforeHero.position.x),"y":mapCoordinate(beforeHero.position.z),"facing":beforeHero.facing,"hits":beforeHero.attacksLanded,"attack_cooldown":game.run.world.heroAttackCooldown(beforeHero),"attack_target":beforeHero.attackObjectId,"charges":beforeHero.charges,"cooldowns":beforeHero.cooldowns,"recharges":beforeHero.recharges}
        var publicDefense = newJArray()
        for oi in 0..<game.run.world.worldObjectCount(beforeHero.id):
          var value: WorldObject
          if game.run.world.worldObjectAt(beforeHero.id,oi,value):
            if (value.team == beforeHero.team and (value.kind == 1 or value.kind == 2 or value.kind == 4)) or (value.team != beforeHero.team and value.kind == 2):
              publicDefense.add(%*{"id":value.id,"kind":value.kind,"team":ord(value.team),"hp":value.hp,"alive":value.alive,"x":mapCoordinate(value.position.x),"y":mapCoordinate(value.position.z),"target":value.targetId})
        var priorMemory = newJObject()
        for name in ["handoffSkips","denseLastTick","denseLastHits","denseSteps","defUntil","defPointX","defPointY","defThreatX","defThreatY","perimeterAnchor"]:
          try:priorMemory[name]= %vm.runtime.getGlobal(name)
          except BasicError:discard
        runHeroScript(game.run,slot)
        if vm.failed:raise newException(ValueError,vm.lastError)
        let actual=game.run.recorder.data.actions[first..<game.run.recorder.data.actions.len]
        if actual != perSlot[slot]:
          echo $(%*{"type":"command_mismatch","tick":game.run.world.tick,"slot":slot,"expected":perSlot[slot],"actual":actual})
          quit(2)
        checked+=actual.len
        if vm.decisions>before:
          inc decisions
          if game.run.world.tick mod sampleEvery==0:
            var memory=newJObject()
            for name in ["responseUntil","responseMode","responseEligible","responseRank","transitDone","transitActive","transitX","transitY","escortId","escortX","escortY","waveChosen","waveCached","criticalUntil","defFrontD","defSentry","defAnchorX","defAnchorY","defHomeX","defHomeY","relayActive","relayId","relayX","relayY","relaySelfD","relayHomeD","relayNearD","handoffSkips","mTracked","mD","mTryX","mTryY","denseSteps","denseLastTick","denseLastHits","motionActive","motionLastHits","recoverySteps","defMotionLimit","bestId","defActive","defUntil","defHoldTicks","defFront","defCount","defAnchor","defPointX","defPointY","defThreatX","defThreatY","defNavX","defNavY","defMoveAccepted","perimeterAnchor","perimeterX","perimeterY","perimeterLastCombat","perimeterEnabled","backdoorActive","coreId","middleRush","liveAnchorId","liveAnchorRetired","creepCoreId","pairedRush","pairAnchorHp","pairMaxHp","arrivalDistanceSq","watchAdvance","watchQuiet","watchAnchor","watchX","watchY","watchReleases","watchPressure","cpAssigned","cpMode","cpQuiet","cpBack","cpAdvance","cpAnchor","cpContact","cpLarge","cpNearbyEnemies","cpHomeAllies","cpRearNeeded","cpWaveUntil","cpWaveCursor","cpTransitions","cpX","cpY","rushStage","rushMoveX","rushMoveY"]:
              try:memory[name]= %vm.runtime.getGlobal(name)
              except BasicError:discard
            let selectedId = vm.runtime.getGlobal("bestId")
            var selected = newJNull()
            for oi in 0..<game.run.world.worldObjectCount(beforeHero.id):
              var value: WorldObject
              if game.run.world.worldObjectAt(beforeHero.id,oi,value) and value.id == selectedId:
                selected = %*{"id":value.id,"kind":value.kind,"hp":value.hp,"alive":value.alive,"x":mapCoordinate(value.position.x),"y":mapCoordinate(value.position.z)}
            echo $(%*{"type":"decision","tick":game.run.world.tick,"slot":slot,"memory":memory,"actions":actual,"self_before":beforeSelf,"selected_public":selected,"public_defense_before":publicDefense,"prior_defense_memory":priorMemory,"public_object_count":game.run.world.worldObjectCount(beforeHero.id)})
    game.run.world.heroTurnStart=(game.run.world.heroTurnStart+1) mod 10
  )
  for slot in probeSlots:
    let h = game.run.world.heroes[slot]
    echo $(%*{"type":"ground_truth_after_tick","tick":game.run.world.tick,
      "slot":slot,"class":ord(h.class),"level":h.level,"maxHp":h.maxHp,"hp":h.hp,"mana":h.mana,
      "position":h.position,"facing":h.facing,"hits":h.attacksLanded,
      "swingTicks":h.swingTicks,"damageLanded":h.damageLanded,
      "target":h.attackObjectId})
  if game.run.stateHash()!=tape.hashes[game.run.world.tick-1]:
    echo $(%*{"type":"hash_mismatch","tick":game.run.world.tick})
    quit(3)
echo $(%*{"type":"summary","controlled_slots":probeSlots,"ticks":game.run.world.tick,"owned_commands_matched":checked,"owned_decisions":decisions,"all_state_hashes_equal":true,"all_actions_consumed":index==tape.actions.len})
