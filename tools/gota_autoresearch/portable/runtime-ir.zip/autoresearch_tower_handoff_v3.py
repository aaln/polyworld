"""Same tower-release behavior with disjoint red/blue memory reuse."""
from dataclasses import replace
from binding import CONTRACTS
import autoresearch_tower_handoff_v2
import autoresearch_blue_current_duty_v1
ALIASES={'towerReleaseId':'responseKind','towerReleaseX':'responseDx','towerReleaseY':'responseDy','towerReleaseUntil':'responseUntil','towerReleaseReady':'responseMode','towerReleaseLastTick':'responseOwnD','towerReleaseStarts':'responseD','towerReleaseMoves':'responseIndex','towerReleaseActive':'responseEligible'}
p=CONTRACTS['red_tower_handoff_v2'];source=p.template
for a,b in ALIASES.items():source=source.replace(a,b)
source=source.replace('responseEligible = 0\nif selfTeam = 0 then','if selfTeam = 0 then\n  responseEligible = 0')
CONTRACTS['red_tower_handoff_v3']=replace(p,template=source,writes=('redTowerRelease',),memory=tuple(ALIASES[x] for x in p.memory),meaning=p.meaning+' Storage revision: use response* slots only on red, where the blue-only response observer never accesses them. Map: '+str(ALIASES)+'. Blue branch and persistent blue response slots are untouched.')

# Compute the repeated squared radius once before its read-only observation loop.
# defMates is scratch from the mutually exclusive defensive branch; it is not
# consumed after these nondefensive loops. No observation or action is removed.
for name,parent in [('lineup_tower_cached_transit_v1','lineup_deployed_cached_v5'),('lineup_tower_cached_duty_v1','lineup_blue_current_duty_v1')]:
 p=CONTRACTS[parent];source=p.template
 import re
 matches=list(re.finditer(r'(?m)^( +)if bestId = 0 or bestDistance > (param_\w+ \* param_\w+ \* (?:1|param_\w+)) then$',source));assert len(matches)==4
 for m in reversed(matches):
  loop=source.rfind('      index = 0\n',0,m.start());assert loop>=0
  source=source[:m.start()]+m[1]+'if bestId = 0 or bestDistance > defMates then'+source[m.end():]
  source=source[:loop]+'      defMates = '+m[2]+'\n'+source[loop:]
 CONTRACTS[name]=replace(p,template=source,meaning=p.meaning+' Equivalent calculation reuse: compute the same nondefensive escort threshold once before each loop in otherwise unused defMates scratch; preserve every selection and observation. Requires full command/state equivalence and native budgets.')
