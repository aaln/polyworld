## Compare every stored canonical state hash in two independently audited tapes.
## No simulation, policy modification, branching or outcome-quality inference.
import std/[os, json]
import ../../replays
let args=commandLineParams()
doAssert args.len==2
let left=loadReplay(args[0])
let right=loadReplay(args[1])
let common=min(left.hashes.len,right.hashes.len)
var runs=newJArray()
var start=1
var equal=true
var equalTicks=0
for index in 0..<common:
  let same=left.hashes[index]==right.hashes[index]
  if same:inc equalTicks
  if index==0:equal=same
  elif same!=equal:
    runs.add(%*{"start_tick":start,"end_tick":index,"equal":equal})
    start=index+1
    equal=same
if common>0:runs.add(%*{"start_tick":start,"end_tick":common,"equal":equal})
echo $(%*{"schema":"gota-audited-state-hash-runs/1",
  "same_setup":left.header.setup==right.header.setup,
  "same_config":left.config==right.config,"common_ticks":common,
  "equal_ticks":equalTicks,"left_ticks":left.hashes.len,"right_ticks":right.hashes.len,
  "runs":runs,"interpretation":"Exact stored canonical world-state hash comparison, paired with independent full replay audits. VM-private globals are outside the world hash; future decisions can still differ after a world-state reconvergence. No isolated decision-quality verdict."})
