## Reconstruct owned VM state by replaying rivals and rerunning our exact source.
## Every generated owned command and every resulting state hash must match tape.
import std/[json, os, strutils]
import ../../game
include ../../bots

proc applyReplayAction(world: World, action: ReplayAction): bool {.discardable.} =
  ## Applies one recorded bot command without requiring its private VM.
  case action.kind
  of ActionWalkTo:
    applyWalkTo(world, action.heroId, action.first, action.second)
  of ActionAttackMove:
    applyAttackMove(
      world, action.heroId, action.first, action.second
    )
  of ActionAttackTarget:
    applyAttackTarget(world, action.heroId, action.first)
  of ActionBuyItem:
    applyBuyItem(world, action.heroId, action.first)
  of ActionUseItem:
    applyUseItem(world, action.heroId, action.first)
  of ActionCastTarget .. ActionCastPoint - 1:
    applyCastTarget(world, action.heroId,
      int32(action.kind - ActionCastTarget), action.first)
  of ActionCastPoint .. ActionManualSpells - 1:
    applyCastPoint(world, action.heroId,
      int32(action.kind - ActionCastPoint), action.first, action.second)
  of ActionManualSpells:
    let index = world.heroIndex(action.heroId)
    if index >= 0:
      world.heroes[index].manualSpells = action.first != 0
    false
  else:
    raise newException(ReplayError, "replay action kind is invalid")

if not game.run.replayMode:raise newException(ValueError,"--replay required")
let tape=game.run.replayData
var controlled:array[10,bool]
for x in getEnv("PROBE_SLOTS").split(','):controlled[parseInt(x)]=true
loadBots(game.run, [BotGroup(path:getEnv("PROBE_POLICY"),count:10)])
game.run.historyPlayback=false
startReplayRecording(uint32(tape.hashes.len))
var index=0
var checked=0
var decisions=0
var controllerCounts:array[10,array[5,int]]
while game.run.world.tick<tape.hashes.len and not game.run.world.gameOver:
  tickWorld(game.run, proc() =
    var perSlot:array[10,seq[ReplayAction]]
    while index<tape.actions.len and tape.actions[index].tick==uint32(game.run.world.tick):
      let a=tape.actions[index]
      if a.kind==ActionManualSpells:discard applyReplayAction(game.run.world,a)
      else:perSlot[heroIndex(game.run.world,a.heroId)].add(a)
      inc index
    for offset in 0..<10:
      let slot=(game.run.world.heroTurnStart+offset) mod 10
      if not controlled[slot]:
        for a in perSlot[slot]:discard applyReplayAction(game.run.world,a)
      else:
        let first=game.run.recorder.data.actions.len
        let vm=game.run.heroVms[slot]
        let before=vm.decisions
        runHeroScript(game.run,slot)
        if vm.failed:
          echo $(%*{"type":"runtime_failure","tick":game.run.world.tick,"slot":slot,"error":vm.lastError,"owned_commands_previously_matched":checked,"all_prior_commands_equal":true,"all_prior_state_hashes_equal":true})
          quit(4)
        let actual=game.run.recorder.data.actions[first..<game.run.recorder.data.actions.len]
        if actual != perSlot[slot]:
          echo $(%*{"type":"command_mismatch","tick":game.run.world.tick,"slot":slot,"expected":perSlot[slot],"actual":actual})
          quit(2)
        checked+=actual.len
        if vm.decisions>before:
          inc decisions
          if vm.runtime.getGlobal("gaActive") != 0:
            inc controllerCounts[slot][0]
            if vm.runtime.getGlobal("defSentry") != 0:inc controllerCounts[slot][1]
            if vm.runtime.getGlobal("gaReady") != 0:inc controllerCounts[slot][2]
            if vm.runtime.getGlobal("perimeterEnabled") != 0:inc controllerCounts[slot][3]
            if vm.runtime.getGlobal("backdoorActive") != 0:inc controllerCounts[slot][4]
          if game.run.world.tick mod 120==0 or vm.lastInstructions > 19000:
            var memory=newJObject()
            for name in ["gaActive","gaReady","gaTethered","bestId","defPointX","defPointY","defGoalX","defGoalY","defSentryRole","defSentry","defMates","pairedRush","defCount","backdoorWatched","backdoorGroupUntil","backdoorFirstSeen","backdoorCommitted","coreId","coreD","backdoorHelpers","defMoveAccepted","defNavX","defNavY","defNavFound","backdoorX","backdoorY","defUntil","defThreatX","defThreatY","coreRespond","coreValue","defFrontX","defFrontY","defFrontD","defGroupSize","perimeterEnabled","backdoorActive","criticalUntil","perimeterLastCombat"]:
              try:memory[name]= %vm.runtime.getGlobal(name)
              except BasicError:discard
            echo $(%*{"type":"decision","tick":game.run.world.tick,"slot":slot,"instructions":vm.lastInstructions,"hp":game.run.world.heroes[slot].hp,"x":mapCoordinate(game.run.world.heroes[slot].position.x),"y":mapCoordinate(game.run.world.heroes[slot].position.z),"memory":memory,"actions":actual})
    game.run.world.heroTurnStart=(game.run.world.heroTurnStart+1) mod 10
  )
  if game.run.stateHash()!=tape.hashes[game.run.world.tick-1]:
    echo $(%*{"type":"hash_mismatch","tick":game.run.world.tick})
    quit(3)
echo $(%*{"type":"controller_counts","fields":["active","emergency","ready","scout_alias","focus_alias"],"by_slot":controllerCounts})
echo $(%*{"type":"summary","ticks":game.run.world.tick,"owned_commands_matched":checked,"owned_decisions":decisions,"all_state_hashes_equal":true,"all_actions_consumed":index==tape.actions.len})
