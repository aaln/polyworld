## Emit every recorded command for already audited replay comparisons.
## This is not a simulation auditor and makes no outcome judgment.
import std/[os,json]
import ../../replays
let args=commandLineParams()
doAssert args.len==1
let replay=loadReplay(args[0])
for action in replay.actions:
  doAssert action.heroId in 100..109
  echo $(%*{"type":"action","tick":action.tick,"slot":action.heroId-100,
    "kind":action.kind,"first":action.first,"second":action.second})
echo $(%*{"type":"summary","ticks":replay.hashes.len,"actions_consumed":replay.actions.len,
  "meaning":"All recorded commands; no simulation re-audit. Pair with pinned completed audit."})
