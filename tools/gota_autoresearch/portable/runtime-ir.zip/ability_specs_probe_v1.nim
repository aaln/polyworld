## Read-only published ability metadata for replay opportunity diagnostics.
import std/json
import ../../content

var rows = newJArray()
for hero in HeroClass:
  for slot in HeroAbilitySlot:
    let ability = heroAbility(hero, slot)
    let spec = ability.abilitySpec
    rows.add(%*{"class":ord(hero),"class_name": $hero,"slot":ord(slot),
      "ability": $ability,"kind": $spec.kind,"casting": $spec.casting,
      "mana_cost":spec.manaCost,"range":spec.range})
echo $rows
