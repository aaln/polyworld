"""Complete observation-only cache calibration, same as the tested fusion observer."""
from dataclasses import replace
from binding import CONTRACTS
from autoresearch_target_work_v1 import target_work
from autoresearch_fused_wave_work_v2 import observe_v2
from autoresearch_scoped_core_response_v3 import cached_reads
from games.gods_of_the_arena.instruments.richard_counter import contracts
import re

p=cached_reads(observe_v2(target_work(CONTRACTS['lineup_critical_recall'])))
source=p.template
matches=list(re.finditer(r'(?m)^( +)if bestId = 0 or bestDistance > (param_\w+ \* param_\w+ \* (?:1|param_\w+)) then$',source));assert len(matches)==4
for m in reversed(matches):
 loop=source.rfind('      index = 0\n',0,m.start());assert loop>=0
 source=source[:m.start()]+m[1]+'if bestId = 0 or bestDistance > defMates then'+source[m.end():]
 source=source[:loop]+'      defMates = '+m[2]+'\n'+source[loop:]
CONTRACTS['lineup_critical_runtime_reference_v2']=replace(p,template=source,meaning=p.meaning+' Compute the invariant nondefensive escort threshold once in defMates scratch. This is the same cache set already in the fusion observer; no critical alarm or decision parameter changes.')
