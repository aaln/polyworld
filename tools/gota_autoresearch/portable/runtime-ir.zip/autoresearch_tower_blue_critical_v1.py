"""Blue critical recall composed with the measured red transit/tower observer."""
from dataclasses import replace
from binding import CONTRACTS
import autoresearch_tower_handoff_v3

p=CONTRACTS['lineup_tower_cached_transit_v1'];source=p.template
alarm='defFrontD <= param_critical_radius * param_critical_radius and defCount >= param_critical_group'
token='if defAnchor <> 0 and ('
assert source.count(token)==2
head,tail=source.rsplit(token,1)
source=head+token+'('+alarm+') or '+tail
token='defUntil = worldTick + defHoldTicks'
assert source.count(token)==2
head,tail=source.rsplit(token,1)
source=head+token+'\n      if '+alarm+' then\n        criticalUntil = worldTick + param_critical_hold\n      end if'+tail
token='if defDx * defDx + defDy * defDy > param_recall_radius * param_recall_radius then'
assert source.count(token)==1
source=source.replace(token,token[:-5]+' and worldTick >= criticalUntil then')
CONTRACTS['lineup_tower_blue_critical_v1']=replace(p,template=source,
 parameters=p.parameters|{'critical_radius':(60,20,80),'critical_group':(2,1,4),'critical_hold':(1200,240,2400)},
 memory=p.memory+('criticalUntil',),
 meaning=p.meaning+' Blue-only composition of the exact critical60 public alarm: '
 'two observed living enemies clustered around the nearest visible threat within60tiles '
 'of the friendly fort, with a standing friendly structure anchor, can start or refresh '
 'a1200tick remote-recall commitment. Ordinary local cancellation is suspended during '
 'that commitment. Red observation and all red behavior are preserved. Missing enemies '
 'remain unknown; no opponent identity or private information is used. Exact full red '
 'and blue source-component command/state reconstruction is required before local qualification.')
