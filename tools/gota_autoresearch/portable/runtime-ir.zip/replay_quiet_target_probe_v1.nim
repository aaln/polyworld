## Read-only selectedtarget/anchor/hero counts from the same cached public observation; no rival hidden state.
## Reconstruct owned VM state by replaying rivals and rerunning our exact source.
## Every generated owned command and every resulting state hash must match tape.
import std/[json, os, strutils]
import ../../game
include ../../bots

proc applyReplayAction(world: World, action: ReplayAction): bool {.discardable.} =
  ## Applies one recorded bot command without requiring its private VM.
  case action.kind
  of ActionWalkTo:
    applyWalkTo(world, action.heroId, action.first, action.second)
  of ActionAttackMove:
    applyAttackMove(
      world, action.heroId, action.first, action.second
    )
  of ActionAttackTarget:
    applyAttackTarget(world, action.heroId, action.first)
  of ActionBuyItem:
    applyBuyItem(world, action.heroId, action.first)
  of ActionUseItem:
    applyUseItem(world, action.heroId, action.first)
  of ActionCastTarget .. ActionCastPoint - 1:
    applyCastTarget(world, action.heroId,
      int32(action.kind - ActionCastTarget), action.first)
  of ActionCastPoint .. ActionManualSpells - 1:
    applyCastPoint(world, action.heroId,
      int32(action.kind - ActionCastPoint), action.first, action.second)
  of ActionManualSpells:
    let index = world.heroIndex(action.heroId)
    if index >= 0:
      world.heroes[index].manualSpells = action.first != 0
    false
  else:
    raise newException(ReplayError, "replay action kind is invalid")

if not game.run.replayMode:raise newException(ValueError,"--replay required")
let tape=game.run.replayData
## Use 1 to inspect brief visibility/recall transitions; default keeps old traces.
let sampleEvery=parseInt(getEnv("PROBE_SAMPLE_EVERY", "120"))
if sampleEvery<1:raise newException(ValueError,"PROBE_SAMPLE_EVERY must be positive")
let slotText=getEnv("PROBE_SLOTS")
if slotText.len==0:raise newException(ValueError,"PROBE_SLOTS required")
var controlled:array[10,bool]
var probeSlots:seq[int]
for item in slotText.split(','):
  let slot=parseInt(item)
  if slot<0 or slot>=10 or controlled[slot]:raise newException(ValueError,"Invalid/duplicate owned slot")
  controlled[slot]=true
  probeSlots.add(slot)
loadBots(game.run, [BotGroup(path:getEnv("PROBE_POLICY"),count:10)])
game.run.historyPlayback=false
startReplayRecording(uint32(tape.hashes.len))
var index=0
var checked=0
var decisions=0
while game.run.world.tick<tape.hashes.len and not game.run.world.gameOver:
  tickWorld(game.run, proc() =
    var perSlot:array[10,seq[ReplayAction]]
    while index<tape.actions.len and tape.actions[index].tick==uint32(game.run.world.tick):
      let a=tape.actions[index]
      if a.kind==ActionManualSpells:discard applyReplayAction(game.run.world,a)
      else:perSlot[heroIndex(game.run.world,a.heroId)].add(a)
      inc index
    for offset in 0..<10:
      let slot=(game.run.world.heroTurnStart+offset) mod 10
      if not controlled[slot]:
        for a in perSlot[slot]:discard applyReplayAction(game.run.world,a)
      else:
        let first=game.run.recorder.data.actions.len
        let vm=game.run.heroVms[slot]
        let before=vm.decisions
        runHeroScript(game.run,slot)
        if vm.failed:raise newException(ValueError,vm.lastError)
        let actual=game.run.recorder.data.actions[first..<game.run.recorder.data.actions.len]
        if actual != perSlot[slot]:
          echo $(%*{"type":"command_mismatch","tick":game.run.world.tick,"slot":slot,"expected":perSlot[slot],"actual":actual})
          quit(2)
        checked+=actual.len
        if vm.decisions>before:
          inc decisions
          if game.run.world.tick mod sampleEvery==0:
            var memory=newJObject()
            for name in ["defSentry","defLastTick","backdoorUntil","backdoorGroupUntil","denseSteps","denseLastTick","denseLastHits","motionActive","motionLastHits","recoverySteps","defMotionLimit","bestId","defActive","defUntil","defHoldTicks","defFront","defCount","defAnchor","defPointX","defPointY","defThreatX","defThreatY","defNavX","defNavY","defMoveAccepted","perimeterAnchor","perimeterX","perimeterY","perimeterLastCombat","perimeterEnabled","backdoorActive","coreId","middleRush","liveAnchorId","liveAnchorRetired","creepCoreId","pairedRush","pairAnchorHp","pairMaxHp","arrivalDistanceSq","watchAdvance","watchQuiet","watchAnchor","watchX","watchY","watchReleases","watchPressure","cpAssigned","cpMode","cpQuiet","cpBack","cpAdvance","cpAnchor","cpContact","cpLarge","cpNearbyEnemies","cpHomeAllies","cpRearNeeded","cpWaveUntil","cpWaveCursor","cpTransitions","cpX","cpY","rushStage","rushMoveX","rushMoveY"]:
              try:memory[name]= %vm.runtime.getGlobal(name)
              except BasicError:discard
            let ownHero = game.run.world.heroes[slot]
            let selectedId = vm.runtime.getGlobal("bestId")
            let anchorId = vm.runtime.getGlobal("perimeterAnchor")
            let anchorX = vm.runtime.getGlobal("perimeterX")
            let anchorY = vm.runtime.getGlobal("perimeterY")
            var selected = newJNull()
            var anchorHp = -1'i32
            var visibleHeroes = 0
            var nearbyHeroes = 0
            for objectIndex in 0..<game.run.world.worldObjectCount(ownHero.id):
              var value: WorldObject
              if game.run.world.worldObjectAt(ownHero.id,objectIndex,value):
                if value.id == selectedId:
                  selected = %*{"id":value.id,"kind":value.kind,"hp":value.hp,"alive":value.alive}
                if value.id == anchorId:anchorHp = value.hp
                if value.kind == 2 and value.team != ownHero.team and value.alive and value.hp > 0:
                  inc visibleHeroes
                  let dx = mapCoordinate(value.position.x) - anchorX
                  let dy = mapCoordinate(value.position.z) - anchorY
                  if dx*dx + dy*dy <= 24*24:inc nearbyHeroes
            let publicView = %*{"selected":selected,"anchor_id":anchorId,"anchor_hp":anchorHp,"visible_live_enemy_heroes":visibleHeroes,"live_enemy_heroes_within24_anchor_tiles":nearbyHeroes}
            echo $(%*{"type":"decision","tick":game.run.world.tick,"slot":slot,"memory":memory,"actions":actual,"public_cached_view":publicView})
    game.run.world.heroTurnStart=(game.run.world.heroTurnStart+1) mod 10
  )
  if game.run.stateHash()!=tape.hashes[game.run.world.tick-1]:
    echo $(%*{"type":"hash_mismatch","tick":game.run.world.tick})
    quit(3)
echo $(%*{"type":"summary","controlled_slots":probeSlots,"ticks":game.run.world.tick,"owned_commands_matched":checked,"owned_decisions":decisions,"all_state_hashes_equal":true,"all_actions_consumed":index==tape.actions.len})
